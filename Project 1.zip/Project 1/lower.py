#!/usr/bin/env python

"""
A filter that convert input to lower case.
"""

import fileinput


def process(line):
    """For each line of input, lower case it."""
    print(line[:-1].lower())


for line in fileinput.input():
    process(line)
