#!/usr/bin/env python

"""
A filter that split lines of text into word per line.
"""

import fileinput


def process(line):
    """For each line of input, split lines into word per line"""
    element=[' ']
    element2=['.',',',':','*','\n','\t','\r',None]
    y=''
    for x in line:
        if x not in element:
            if x not in element2:
                y=y+x
        if x in element:
            y=y+'\n'
        if x in element2:
            y=y
    print(y)

for file in fileinput.input():
    process(file)
