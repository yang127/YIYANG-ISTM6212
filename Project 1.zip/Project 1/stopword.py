#!/usr/bin/env python

"""
A filter that removes stop words.
"""

import fileinput
import re

def process(line):
    stop_words = ["it","she","in","to","for","with","a","and","the","is"]
    pattern =re.compile('\w+')
    file=pattern.findall(line)
    
    for i in file:
        if i not in stop_words:
            print(i)
            
for file in fileinput.input():
    process(file)

        
         
   



